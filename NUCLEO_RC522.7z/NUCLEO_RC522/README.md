接线:
RC522 引脚	NUCLEO-L476RG 引脚	功能说明
SDA (SS)	D10 (或 PB6)	片选信号 (Slave Select)
SCK	D13 (或 PA5)	SPI 时钟 (Serial Clock)
MOSI	D11 (或 PA7)	主机输出，从机输入
MISO	D12 (或 PA6)	主机输入，从机输出
IRQ	不连接	中断请求 (本示例不使用)
GND	GND	地线
RST	D9 (或 PC7)	复位引脚
3.3V	3.3V	电源