#ifndef INC_RC522_H_
#define INC_RC522_H_

#include "stm32l4xx_hal.h"

// 状态码
#define MI_OK                          0  // 成功
#define MI_NOTAGERR                    1  // 无卡错误
#define MI_ERR                         2  // 一般错误

// MFRC522 命令字
#define PCD_IDLE                       0x00
#define PCD_AUTHENT                    0x0E
#define PCD_RECEIVE                    0x08
#define PCD_TRANSMIT                   0x04
#define PCD_TRANSCEIVE                 0x0C
#define PCD_RESETPHASE                 0x0F
#define PCD_CALCCRC                    0x03

// Mifare_One 卡片命令字
#define PICC_REQIDL                    0x26 // 寻天线区内未进入休眠状态
#define PICC_REQALL                    0x52 // 寻天线区内全部卡
#define PICC_ANTICOLL1                 0x93 // 防冲撞
#define PICC_SELECTTAG                 0x93 // 选卡
#define PICC_AUTHENT1A                 0x60 // 验证A密钥
#define PICC_AUTHENT1B                 0x61 // 验证B密钥
#define PICC_READ                      0x30 // 读块
#define PICC_WRITE                     0xA0 // 写块
#define PICC_DECREMENT                 0xC0 // 扣款
#define PICC_INCREMENT                 0xC1 // 充值
#define PICC_RESTORE                   0xC2 // 调块数据到缓冲区
#define PICC_TRANSFER                  0xB0 // 保存缓冲区中数据
#define PICC_HALT                      0x50 // 休眠

// MFRC522 寄存器地址 (保持不变)
#define CommandReg                     0x01
#define ComIEnReg                      0x02
#define DivIEnReg                      0x03
#define ComIrqReg                      0x04
#define DivIrqReg                      0x05
#define ErrorReg                       0x06
#define Status1Reg                     0x07
#define Status2Reg                     0x08
#define FIFODataReg                    0x09
#define FIFOLevelReg                   0x0A
#define WaterLevelReg                  0x0B
#define ControlReg                     0x0C
#define BitFramingReg                  0x0D
#define CollReg                        0x0E
#define ModeReg                        0x11
#define TxModeReg                      0x12
#define RxModeReg                      0x13
#define TxControlReg                   0x14
#define TxAutoReg                      0x15
#define RFCfgReg                       0x26
#define TModeReg                       0x2A
#define TPrescalerReg                  0x2B
#define TReloadRegH                    0x2C
#define TReloadRegL                    0x2D
#define CRCResultRegM                  0x21
#define CRCResultRegL                  0x22
#define VersionReg                     0x37


//===== 函数原型声明 =====//

// 基础通信
void MFRC522_WriteRegister(uint8_t addr, uint8_t val);
uint8_t MFRC522_ReadRegister(uint8_t addr);

// 核心功能
void MFRC522_Init(void);
void MFRC522_Reset(void);
uint8_t MFRC522_ToCard(uint8_t command, uint8_t* sendData, uint8_t sendLen, uint8_t* backData, uint16_t* backLen);

// 高级卡片操作API
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t* TagType);
uint8_t MFRC522_Anticoll(uint8_t* serNum);
uint8_t MFRC522_SelectTag(uint8_t* serNum);
uint8_t MFRC522_Auth(uint8_t authMode, uint8_t BlockAddr, uint8_t* Sectorkey, uint8_t* serNum);
uint8_t MFRC522_Read(uint8_t blockAddr, uint8_t* recvData);
uint8_t MFRC522_Write(uint8_t blockAddr, uint8_t* writeData);
void MFRC522_Halt(void);
void MFRC522_CalculateCRC(uint8_t* pIndata, uint8_t len, uint8_t* pOutData);

// 内部辅助函数
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask);
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask);
void MFRC522_AntennaOn(void);
void MFRC522_AntennaOff(void);

#endif /* INC_RC522_H_ */
